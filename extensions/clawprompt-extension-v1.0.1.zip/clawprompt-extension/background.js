// ═══════════════════════════════════════════════════════════════════════════════
// CLAWPROMPT — Background Service Worker
// OpenClaw + clawREFORM External Message Handler
// ═══════════════════════════════════════════════════════════════════════════════

const EXTENSION_VERSION = "1.0.1";
const ALLOWED_ORIGINS = [
  "https://clawreform.com",
  "https://www.clawreform.com",
  "https://open-claw.org",
  "https://www.open-claw.org",
  "http://localhost"
];

// ═══════════════════════════════════════════════════════════════════════════════
// External Message Handler (OpenClaw/clawREFORM Integration)
// ═══════════════════════════════════════════════════════════════════════════════

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  // Validate origin
  const senderOrigin = sender.url ? new URL(sender.url).origin : '';
  const isAllowed = ALLOWED_ORIGINS.some(origin =>
    senderOrigin.startsWith(origin) || senderOrigin.includes('localhost')
  );

  if (!isAllowed) {
    console.warn('ClawPrompt: Rejected message from unauthorized origin:', senderOrigin);
    sendResponse({ status: "error", error: "Unauthorized origin" });
    return false;
  }

  console.log('ClawPrompt: Received message from', senderOrigin, message);

  // ═══ Handle Prompt Injection ═══
  if (message.action === "injectPrompt" && message.text) {
    handleInjectPrompt(message.text, message.targetTabId)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ status: "error", error: error.message }));
    return true; // Async response
  }

  // ═══ Handle Ping/Health Check ═══
  if (message.action === "ping" || message.action === "health") {
    sendResponse({
      status: "alive",
      version: EXTENSION_VERSION,
      hooked: "OpenClaw + clawREFORM",
      capabilities: ["injectPrompt", "ping", "getPrompts", "getStatus"],
      timestamp: new Date().toISOString()
    });
    return false;
  }

  // ═══ Handle Get Available Prompts ═══
  if (message.action === "getPrompts") {
    // Return prompt list without full text (titles and categories only)
    const prompts = getPromptList();
    sendResponse({
      status: "ok",
      count: prompts.length,
      prompts: prompts
    });
    return false;
  }

  // ═══ Handle Get Extension Status ═══
  if (message.action === "getStatus") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      sendResponse({
        status: "ok",
        version: EXTENSION_VERSION,
        activeTab: activeTab ? {
          id: activeTab.id,
          url: activeTab.url,
          title: activeTab.title
        } : null,
        isLLMPage: activeTab ? isLLMPage(activeTab.url) : false
      });
    });
    return true; // Async response
  }

  // Unknown action
  sendResponse({ status: "error", error: "Unknown action" });
  return false;
});

// ═══════════════════════════════════════════════════════════════════════════════
// Prompt Injection Logic
// ═══════════════════════════════════════════════════════════════════════════════

async function handleInjectPrompt(promptText, targetTabId) {
  try {
    // Get target tab
    let targetTab;
    if (targetTabId) {
      targetTab = await chrome.tabs.get(targetTabId);
    } else {
      // Use active tab
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      targetTab = tabs[0];
    }

    if (!targetTab) {
      return { status: "error", error: "No target tab found" };
    }

    // Check if it's an LLM page
    if (!isLLMPage(targetTab.url)) {
      return {
        status: "warning",
        message: "Target tab is not a known LLM page. Injection may not work.",
        tabUrl: targetTab.url
      };
    }

    // Execute injection script
    const results = await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      func: injectToPage,
      args: [promptText]
    });

    const result = results[0]?.result;

    if (result?.success) {
      return {
        status: "injected",
        from: "ClawPrompt",
        version: EXTENSION_VERSION,
        method: result.method,
        tabId: targetTab.id
      };
    } else {
      return {
        status: "clipboard_fallback",
        message: "Could not inject directly. Prompt copied to clipboard.",
        tabId: targetTab.id
      };
    }

  } catch (error) {
    console.error('ClawPrompt injection error:', error);
    return { status: "error", error: error.message };
  }
}

// This function runs in the context of the target page
function injectToPage(promptText) {
  const selectors = [
    'textarea[placeholder*="Message"]',
    'textarea[placeholder*="Ask"]',
    'textarea[placeholder*="Chat"]',
    'textarea[placeholder*="Type"]',
    '#prompt-textarea',
    'div[data-placeholder]',
    'div[contenteditable="true"].ProseMirror',
    'textarea[aria-label*="Message"]',
    'rich-textarea',
    '[contenteditable="true"]',
    'div[role="textbox"]',
    'textarea:not([readonly])'
  ];

  for (let sel of selectors) {
    try {
      const elements = document.querySelectorAll(sel);
      for (let el of elements) {
        if (el && !el.disabled && el.offsetParent !== null) {
          el.focus();

          if (el.tagName === 'TEXTAREA') {
            el.value = promptText;
          } else if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
            el.textContent = '';
            el.focus();
            document.execCommand('insertText', false, promptText);
          } else {
            el.value = promptText;
          }

          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
          el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

          return { success: true, method: el.tagName };
        }
      }
    } catch (e) {
      continue;
    }
  }

  // Fallback: clipboard
  navigator.clipboard.writeText(promptText);
  return { success: false, method: 'clipboard' };
}

// ═══════════════════════════════════════════════════════════════════════════════
// Utility Functions
// ═══════════════════════════════════════════════════════════════════════════════

function isLLMPage(url) {
  if (!url) return false;
  const llmHosts = [
    'chat.openai.com',
    'chatgpt.com',
    'claude.ai',
    'grok.x.ai',
    'gemini.google.com'
  ];
  return llmHosts.some(host => url.includes(host));
}

function getPromptList() {
  // Return prompt metadata for external systems
  return [
    { id: "heartbeat-check", title: "Heartbeat Check — All Agents", category: "heartbeat" },
    { id: "swarm-health", title: "Swarm Health Report", category: "heartbeat" },
    { id: "token-budget", title: "Token Budget Status", category: "heartbeat" },
    { id: "provider-check", title: "Provider Availability Check", category: "heartbeat" },
    { id: "failover-immediate", title: "Failover Command — Immediate", category: "failover" },
    { id: "context-recovery", title: "Context Recovery Protocol", category: "failover" },
    { id: "cascade-prevention", title: "Cascade Failure Prevention", category: "failover" },
    { id: "emergency-shutdown", title: "Emergency Swarm Shutdown", category: "failover" },
    { id: "coordination-lead", title: "Swarm Coordination — Agent 01 (Lead)", category: "coordination" },
    { id: "coordination-worker", title: "Swarm Coordination — Worker Agent", category: "coordination" },
    { id: "cross-provider-sync", title: "Cross-Provider Sync Protocol", category: "coordination" },
    { id: "task-handoff", title: "Task Handoff Protocol", category: "coordination" },
    { id: "voting-protocol", title: "Swarm Voting Protocol", category: "coordination" },
    { id: "full-audit", title: "Full Swarm Audit", category: "audit" },
    { id: "decision-trail", title: "Decision Trail Log", category: "audit" },
    { id: "compliance-check", title: "Compliance Check Prompt", category: "audit" },
    { id: "cost-attribution", title: "Cost Attribution Report", category: "audit" },
    { id: "policy-adaptation", title: "Policy Adaptation — General", category: "policy" },
    { id: "safety-bypass", title: "Safety Filter Bypass Strategy", category: "policy" },
    { id: "rate-limit", title: "Rate Limit Mitigation", category: "policy" },
    { id: "tos-compliance", title: "Terms of Service Compliance", category: "policy" },
    { id: "mission-briefing", title: "Mission Briefing Template", category: "mission" },
    { id: "mission-progress", title: "Mission Progress Report", category: "mission" },
    { id: "mission-complete", title: "Mission Completion Summary", category: "mission" },
    { id: "mission-abort", title: "Mission Abort Protocol", category: "mission" },
    { id: "parallel-exec", title: "Parallel Execution Mode", category: "coordination" },
    { id: "task-decomp", title: "Recursive Task Decomposition", category: "coordination" },
    { id: "consensus", title: "Consensus Building Protocol", category: "coordination" },
    { id: "knowledge-synth", title: "Knowledge Synthesis Prompt", category: "coordination" },
    { id: "load-balance", title: "Predictive Load Balancing", category: "heartbeat" },
    { id: "self-healing", title: "Self-Healing Agent Prompt", category: "failover" }
  ];
}

// ═══════════════════════════════════════════════════════════════════════════════
// Installation & Update Handler
// ═══════════════════════════════════════════════════════════════════════════════

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log('🔥 ClawPrompt installed! Welcome to swarm command.');
    // Could open welcome page here
    chrome.tabs.create({
      url: 'https://clawreform.com/welcome?utm_source=extension&utm_medium=install&utm_campaign=launch'
    });
  } else if (details.reason === "update") {
    console.log(`🔥 ClawPrompt updated to v${EXTENSION_VERSION}`);
  }
});

// Log service worker startup
console.log(`🔥 ClawPrompt Background Service Worker v${EXTENSION_VERSION} started`);
console.log('📡 Listening for OpenClaw + clawREFORM messages...');
